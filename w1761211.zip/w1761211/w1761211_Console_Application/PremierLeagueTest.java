import org.junit.*;
import java.time.LocalDate;
/*The following class was used for JUNIT testing which was tested on few of the premier league manager methods
** to highlight that the expected result was produced from certain methods such adding a club, relegating a club
and adding a played match. 
This test class was compiled and run through cmd with the following cmd promots
Junit compilation :-> 
javac -cp junit-4.12.jar;. PremierLeagueTest.java
Junit run test code :-> 
java -cp junit-4.12.jar;hamcrest-core-1.3.jar;. org.junit.runner.JUnitCore PremierLeagueTest
Tutorial reference link : https://www.codejava.net/testing/how-to-compile-and-run-junit-tests-in-command-line
**/

import static org.junit.Assert.*;
public class PremierLeagueTest {
	private PremierLeagueManager plm = new PremierLeagueManager();
	SportsClub Manchester = new FootballClub("Manchester","UK",20, 2000);
	SportsClub Chelsea = new FootballClub("Chelsea","UK",22, 2002);


	@Test
	public void testAddFootballClub() {
		plm.addSportsClub (Manchester);
		// Testing if the following club was added
		assertEquals("The "+ Manchester.getClubName() +" club was successfully added!",Manchester.getClubName(), plm.retrieveFootballClub( "Manchester").getClubName());
	}

	@Test
	public void testRelegateFootballClub() {
		plm.addSportsClub (Chelsea);
		plm.relegateSportsClub(Chelsea.getClubName());
		assertEquals(Chelsea.getClubName() + " has been successfully relegated!",null, plm.retrieveFootballClub( "Chelsea")); // expected club name
	}

	@Test
	public void testAddPlayedMatch() {
		plm.addSportsClub(Chelsea);
		plm.addSportsClub(Manchester);
		Object foundMatch = null;
		FootballMatch footballMatch = new FootballMatch((FootballClub)Chelsea, (FootballClub)Manchester,10,12, LocalDate.of(2000,10,23));
		plm.addPlayedMatch(footballMatch, true);
		for(FootballMatch individualMatch: plm.returnMatches()){
			if(individualMatch.equals(footballMatch)){
				foundMatch = footballMatch;
				break;
			}
		}
		assertEquals("The following Football match has successfully taken place ", footballMatch,foundMatch);
	}
}     